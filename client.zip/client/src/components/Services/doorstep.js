export const doorstepServiceData = {
  title: {
    first: "",
    last: "",
  },
  description: {
    first: "",
    last: "",
  },
  services: [
    {
      title: "",
      list: [],
      url: "",
    },
    {
      title: "",
      list: [],
      url: [],
    },
  ],
  videoUrl: "https://www.youtube.com/embed/748R1A46RwU?controls=1",
  servicesDescription: [
    {
      title: {
        first: "",
        second: "",
      },
      subPoints: [
        {
          title: "",
          points: [],
        },
      ],
      description: "",
      points: [],
    },
  ],
  faqs: [{}],
};
