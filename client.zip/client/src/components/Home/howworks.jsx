import React from 'react'
import './howworks.css'

const Howworks = () => {
  return (
    <>
       <div className='how-works-main-con'>
            
       </div>
    </>
  )
}

export default Howworks